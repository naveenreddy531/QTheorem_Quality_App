import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { RouterModule } from '@angular/router';

// import {FormsModule, ReactiveFormsModule} from '@angular/forms';
// import {MatNativeDateModule} from '@angular/material';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { ApiservicesService } from './shared/apiservices.service';
import { GraphComponent } from './component/graph/graph.component';

import { FusionChartsModule } from 'angular-fusioncharts';

// Load FusionCharts
import * as FusionCharts from 'fusioncharts';
// Load Charts module
import * as Charts from 'fusioncharts/fusioncharts.charts';
// import { ChartModule } from 'angular2-highcharts';
// import * as highcharts from 'Highcharts';
//import * as Highcharts from 'angular-highcharts';
//import * as highcharts from 'Highcharts';
// Load fusion theme
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { LoginComponent } from './component/login/login.component';
import { MapsComponent } from './component/maps/maps.component';

import { AgmCoreModule } from 'angular2-google-maps/core';
import { ResponsiveGraphComponent } from './component/responsive-graph/responsive-graph.component';
import { HomeComponent } from './component/home/home.component';
import { HomeComComponent } from './component/home-com/home-com.component';
import { SidebarDirective } from './sidebar.directive';
import { HistoryComponent } from './component/history/history.component';
import { SectionComponent } from './component/section/section.component';
import { Ng2TableModule } from 'ng2-table/ng2-table';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { PaginationComponent, PaginationModule } from 'ng2-bootstrap';
import { ReportsComponent } from './component/reports/reports.component';
import { ScrolltopComponent } from './utility/scrolltop/scrolltop.component';
import { SidebarComponent } from './component/sidebar/sidebar.component';

import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { AngularDateTimePickerModule } from 'angular2-datetimepicker';

//import { AngularFontAwesomeModule } from 'angular-font-awesome';
// import { NgTableComponent, 
//   NgTableFilteringDirective,
//    NgTablePagingDirective, 
//    NgTableSortingDirective } from 'ng2-table/ng2-table';

import * as zoomline from 'fusioncharts/fusioncharts.zoomline';
// Add dependencies to FusionChartsModule
FusionChartsModule.fcRoot(FusionCharts, Charts, FusionTheme,zoomline)

const googleMapsCore = AgmCoreModule.forRoot({
  apiKey : 'AIzaSyDGtrrj_EV6ZQM74xNeWZD8ux_eUYRX6kU',
});
//AIzaSyBAd1NKLU--SZJgFupowhOxeqbvKL0LACY
@NgModule({
  declarations: [
    AppComponent,
    GraphComponent,
    LoginComponent,
    MapsComponent,
    MapsComponent,
    ResponsiveGraphComponent,
    HomeComponent,
    HomeComComponent,
    SidebarDirective,
    HistoryComponent,
    SectionComponent,
    ReportsComponent,
    ScrolltopComponent,
    SidebarComponent
    
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    googleMapsCore,
    FusionChartsModule,
    Ng2TableModule,
    PaginationModule.forRoot(),
    AngularMultiSelectModule,
    AngularDateTimePickerModule,
   
    //ChartModule.forRoot(highcharts),
    //AngularFontAwesomeModule,
    //   HttpClientModule,
    //   MatNativeDateModule,
    // ReactiveFormsModule,
    RouterModule.forRoot(
      [
        { path: "login", 
          component: LoginComponent
        },
        {
          path: 'graph',
          component: GraphComponent
        },{
          path: 'maps',
          component: MapsComponent
        },
        {
          path: 'test',
          component: HomeComponent
        },
        {
          path: 'dashboard',
          component: ResponsiveGraphComponent
        },
        {
          path: 'home',
          component: HomeComComponent
        },
        {
          path: 'history',
          component: HistoryComponent
        },
        {
          path: 'station',
          component: SectionComponent
        },
        {
          path: 'reports',
          component: ReportsComponent
        },
        {
          path: 'sidebar',
          component: SidebarComponent
        },
        
        
      ]
    )
  ],
  providers: [ApiservicesService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule { }
