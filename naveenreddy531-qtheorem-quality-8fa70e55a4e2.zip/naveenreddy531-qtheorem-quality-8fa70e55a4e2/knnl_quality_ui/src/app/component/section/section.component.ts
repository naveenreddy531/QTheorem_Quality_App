import { Component, OnInit } from '@angular/core';
import { ApiservicesService } from '../../shared/apiservices.service';
import { Router } from '@angular/router';
import * as moment from 'moment'
@Component({
  selector: 'app-section',
  templateUrl: './section.component.html',
  styleUrls: ['./section.component.css']
})
export class SectionComponent implements OnInit {

  public rows: Array<any> = [];
  // public columns:Array<any> = [
  //   {title: 'Name', name: 'name', filtering: {filterString: '', placeholder: 'Filter by name'}},
  //   {title: 'Position',name: 'position', sort: false,filtering: {filterString: '', 
  //   placeholder: 'Filter by position'}},
  //   {title: 'Office', className: ['office-header', 'text-success'], name: 'office', sort: 'asc'},
  //   {title: 'Extn.', name: 'ext', sort: '', filtering: {filterString: '', placeholder: 'Filter by extn.'}},
  //   {title: 'Start date', className: 'text-warning', name: 'startDate'},
  //   {title: 'Salary ($)', name: 'salary'}
  // ];
  public columns: Array<any> = [
    { title: 'Division', name: 'division', filtering: { filterString: '', placeholder: 'Filter by division' } },
    {
      title: 'Station', name: 'stationName', sort: false, filtering: {
        filterString: '',
        placeholder: 'Filter by station'
      }
    },
    { title: 'Category', className: ['office-header', 'text-success'], name: 'stationCategory', sort: 'asc', href: 'https://www.google.com' },
    { title: 'Type.', name: 'stationType', sort: '', filtering: { filterString: '', placeholder: 'Filter by type.' } },
    { title: 'Last Data Recieved', className: 'text-warning', name: 'lastDataRecieved' },
    { title: 'Status', name: 'active' },
    { title: 'HideStation', name: 'HideStation', className: ['hide-header',] }
  ];
  data: any[] = [];
  private data1: Array<any>;
  showHome: boolean;
  showTags: boolean = true;

  public constructor(private shared: ApiservicesService, private router: Router) {
    this.length = this.data.length;
    this.data1 = this.shared.accordionHeader;
    this.data1.forEach(item => {

      item.stations.forEach(element => {
        let lastDataReceived: string;
        lastDataReceived = element.historyData[0].date;

        this.data.push({
          "division": item.division, "stationName": '<a style="text-decoration: underline;color: blue;" (click)="test()">' + element.stationName + '</a>', "stationCategory": element.stationCategory,
          "stationType": element.stationType, "lastDataRecieved": lastDataReceived,
          "active": '<span style="background-color: limegreen;font-size: smaller;">' + element.active + '</span>', "HideStation": element.stationName
        });
        console.log(this.data);
        //       <span class="class1">&nbsp;&nbsp;&nbsp;</span>
        // <label>Station Sending Data</label>
        // "stationName":'<a (click)="test('+item.division+')">' + element.stationName + '</a>'
        //this.router.navigate(['/maps']); 
        //<a (click)="showForgotPwdDiv()" id="forget-password" class="forget-password">Forgot Password?</a>
      });
    });

  }

  test() {
    alert();
  }
  public ngOnInit(): void {

    this.onChangeTable(this.config);

    const $menu = $('#burger');
    const $sidebar = $('.sidebar');
    const $sidebarItemTitles = $('.sidebar-item-title');
    const $sideBar1 = $('#sideBar1');
    const $sideBar2 = $('#sideBar2');
    const $sideBar3 = $('#sideBar3');
    let isOpen = false;
    $sideBar1.addClass('hide');
    $sideBar2.addClass('hide');
    $sideBar3.addClass('hide');
    $menu.on('click', () => {
      if (isOpen) {
        $sidebarItemTitles.addClass('hide');
        $sidebar.removeClass('expanded');
        this.showTags = true;

      } else {
        $sidebarItemTitles.removeClass('hide');
        $sidebar.addClass('expanded');
        this.showTags = false;
      }
      isOpen = !isOpen
    });



    (<any>$('input[name="daterangessssss"]')).daterangepicker({
      opens: 'left',
      ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
      }
    }, function (start, end, label) {
      console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
    });

    $(document).mouseup(function (e) {
      var container_1 = $("#homeBarDiv");
      var container_2 = $("#navbarSupportedContent1");
      var container_3 = $("#stationBarDiv");
      var container_4 = $("#reportsBarDiv");
      const $sideBox1 = $('#active-1');
      const $sideBox2 = $('#active-2');
      const $sideBox3 = $('#active-3');
      $sideBox1.addClass('activeClass');

      // if the target of the click isn't the container nor a descendant of the container
      if ((!container_1.is(e.target) && container_1.has(e.target).length === 0) ||
        (!container_2.is(e.target) && container_2.has(e.target).length === 0) ||
        (!container_3.is(e.target) && container_3.has(e.target).length === 0) ||
        (!container_4.is(e.target) && container_4.has(e.target).length === 0)) {
        container_1.hide();
        container_2.hide();
        container_3.hide();
        container_4.hide();
        $sideBox1.removeClass('activeClass');
        $sideBox2.removeClass('activeClass');
        $sideBox3.removeClass('activeClass');
      }
    });


  }

  showSideBarTags() {
    this.showTags = true;
  }

  public page: number = 1;
  public itemsPerPage: number = 10;
  public maxSize: number = 5;
  public numPages: number = 1;
  public length: number = 0;

  public config: any = {
    paging: true,
    sorting: { columns: this.columns },
    filtering: { filterString: '' },
    className: ['table-striped', 'table-bordered']
  };


  public changePage(page: any, data: Array<any> = this.data): Array<any> {
    let start = (page.page - 1) * page.itemsPerPage;
    let end = page.itemsPerPage > -1 ? (start + page.itemsPerPage) : data.length;
    return data.slice(start, end);
  }

  public changeSort(data: any, config: any): any {
    if (!config.sorting) {
      return data;
    }

    let columns = this.config.sorting.columns || [];
    let columnName: string = void 0;
    let sort: string = void 0;

    for (let i = 0; i < columns.length; i++) {
      if (columns[i].sort !== '' && columns[i].sort !== false) {
        columnName = columns[i].name;
        sort = columns[i].sort;
      }
    }

    if (!columnName) {
      return data;
    }

    // simple sorting
    return data.sort((previous: any, current: any) => {
      if (previous[columnName] > current[columnName]) {
        return sort === 'desc' ? -1 : 1;
      } else if (previous[columnName] < current[columnName]) {
        return sort === 'asc' ? -1 : 1;
      }
      return 0;
    });
  }

  public changeFilter(data: any, config: any): any {
    let filteredData: Array<any> = data;
    this.columns.forEach((column: any) => {
      if (column.filtering) {
        filteredData = filteredData.filter((item: any) => {
          return item[column.name].match(column.filtering.filterString);
        });
      }
    });

    if (!config.filtering) {
      return filteredData;
    }

    if (config.filtering.columnName) {
      return filteredData.filter((item: any) =>
        item[config.filtering.columnName].match(this.config.filtering.filterString));
    }

    let tempArray: Array<any> = [];
    filteredData.forEach((item: any) => {
      let flag = false;
      this.columns.forEach((column: any) => {
        if (item[column.name].toString().match(this.config.filtering.filterString)) {
          flag = true;
        }
      });
      if (flag) {
        tempArray.push(item);
      }
    });
    filteredData = tempArray;

    return filteredData;
  }

  public onChangeTable(config: any, page: any = { page: this.page, itemsPerPage: this.itemsPerPage }): any {
    if (config.filtering) {
      Object.assign(this.config.filtering, config.filtering);
    }

    if (config.sorting) {
      Object.assign(this.config.sorting, config.sorting);
    }

    let filteredData = this.changeFilter(this.data, this.config);
    let sortedData = this.changeSort(filteredData, this.config);
    this.rows = page && config.paging ? this.changePage(page, sortedData) : sortedData;
    this.length = sortedData.length;
  }

  public onCellClick(data: any, columns, index): any {
    console.log(data);
    if (data.column === "stationName") {
      let stationName = data.row.HideStation;
      this.shared.setSelectedStation(stationName);
      this.router.navigate(['/dashboard']);
    }
    // alert(columns);
  }

  routeTo(url) {
    if (url != null || url != undefined) {
      let route = '/' + url
      this.router.navigate([route]);
    }
  }

  /* SIDE BAR START */
  showHomeBar() {
    if (this.showHome == false) {
      this.showHome = true;
    }
    else {
      this.showHome = false;
    }
  }

  outOfAccordion() {

    $('#navbarSupportedContent1').hide();


    $('#navbarSupportedContent1').click(function (event) {
      event.stopPropagation();
    });
  }

  showAccordion() {
    $('#navbarSupportedContent1').show();
  }

  outOfHomeDiv() {
    $('#homeBarDiv').hide();
    $('#homeBarDiv').click(function (event) {
      event.stopPropagation();
    });
  }

  showHomeDiv() {
    $('#homeBarDiv').show();
    const $sideBox = $('#active-1');
    $sideBox.addClass('activeClass');
  }

  outOfStationDiv() {
    $('#stationBarDiv').hide();
    $('#stationBarDiv').click(function (event) {
      event.stopPropagation();
    });
  }

  showStationDiv() {
    $('#stationBarDiv').show();
    const $sideBox = $('#active-2');
    $sideBox.addClass('activeClass');
  }

  outOfReportsDiv() {
    $('#reportsBarDiv').hide();
    $('#reportsBarDiv').click(function (event) {
      event.stopPropagation();
    });
  }

  showReportsDiv() {
    $('#reportsBarDiv').show();
    const $sideBox = $('#active-3');
    $sideBox.addClass('activeClass');
  }

  /* SIDE BAR END */

}
