import { Component, OnInit } from '@angular/core';
import { ApiservicesService } from '../../shared/apiservices.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-maps',
  templateUrl: './maps.component.html',
  styleUrls: ['./maps.component.css']
})



export class MapsComponent implements OnInit {
lat;
lng;
markers: any[] = [];
showSideBar: boolean;
dataSource: Object;
showHome: boolean;
showTags: boolean = true;
showStationDetails: boolean;
  chartConfig: Object;
  constructor(private shared : ApiservicesService, private router: Router) {
    this.showSideBar = false;
    this.lat = 13.8330;
    this.lng = 75.7081;

    this.markers = [
      {
        lat: this.shared.currentLat,
        lng: this.shared.currentLong 
      }
    ];

   }

   openNav(){
     if(this.showSideBar){
       this.showSideBar =false;
     }
     else{
       this.showSideBar = true;
     }
   }

   closeNav(){
     this.showSideBar = false;
   }

   mapClick(){
    
      this.showStationDetails = true;
   
  }
 
  ngOnInit() {

    this.showStationDetails = false;

    const $menu = $('#burger');
    const $sidebar = $('.sidebar');
    const $sidebarItemTitles = $('.sidebar-item-title');
    const $sideBar1 = $('#sideBar1');
    const $sideBar2 = $('#sideBar2');
    const $sideBar3 = $('#sideBar3');
    const $homeTitle = $('#homeTitle');

    let isOpen = false;
    $sideBar1.addClass('hide');
    $sideBar2.addClass('hide');
    $sideBar3.addClass('hide');
    $menu.on('click', () => {
      if (isOpen) {
        $sidebarItemTitles.addClass('hide');
        $sidebar.removeClass('expanded');
        $homeTitle.removeClass('removeBold');
        $homeTitle.addClass('bold');
        this.showTags = true;

      } else {
        $sidebarItemTitles.removeClass('hide');
        $sidebar.addClass('expanded');
        $homeTitle.removeClass('bold');
        $homeTitle.addClass('removeBold');
        this.showTags = false;
      }
      isOpen = !isOpen
    });

    $(document).mouseup(function (e) {
      var container_1 = $("#homeBarDiv");
      var container_2 = $("#navbarSupportedContent1");
      var container_3 = $("#stationBarDiv");
      var container_4 = $("#reportsBarDiv");
      const $sideBox1 = $('#active-1');
      const $sideBox2 = $('#active-2');
      const $sideBox3 = $('#active-3');
      $sideBox1.addClass('activeClass');

      // if the target of the click isn't the container nor a descendant of the container
      if ((!container_1.is(e.target) && container_1.has(e.target).length === 0) ||
        (!container_2.is(e.target) && container_2.has(e.target).length === 0) ||
        (!container_3.is(e.target) && container_3.has(e.target).length === 0) ||
        (!container_4.is(e.target) && container_4.has(e.target).length === 0)) {
        container_1.hide();
        container_2.hide();
        container_3.hide();
        container_4.hide();
        $sideBox1.removeClass('activeClass');
        $sideBox2.removeClass('activeClass');
        $sideBox3.removeClass('activeClass');
      }
    });
  

    this.chartConfig = {
      width: '400',
      height: '200',
      type: 'column2d',
      dataFormat: 'json',
      align:'right'
  };

    this.dataSource = {
      "chart": {
        "caption": "Countries With Most Oil Reserves [2017-18]",
        "subCaption": "In MMbbl = One Million barrels",
        "xAxisName": "Country",
        "yAxisName": "Reserves (MMbbl)",
        "numberSuffix": "K",
        "theme": "gammel",
        "exportEnabled":"1"
      },
      "data": [{
        "label": "Venezuela",
        "value": "290"
      }, {
        "label": "Saudi",
        "value": "260"
      }, {
        "label": "Canada",
        "value": "180"
      }, {
        "label": "Iran",
        "value": "140"
      }, {
        "label": "Russia",
        "value": "115"
      }, {
        "label": "UAE",
        "value": "100"
      }, {
        "label": "US",
        "value": "30"
      }, {
        "label": "China",
        "value": "30"
      }]
    };

    this.markers = [
      {
        lat: 13.8330,
        lng: 75.7081 
      },
      {
        lat: 14.4644,
        lng: 75.9218
      },
      {
        lat: 14.3519,
        lng: 75.7397
      }
    ];

   
   
    // this.lat = this.shared.currentLat;
    // this.lng = this.shared.currentLong;

    // this.markers = [
    //   {
    //     lat: this.shared.currentLat,
    //     lng: this.shared.currentLong 
    //   }
    // ];

    

    


  }

  routeTo(url) {
    if (url != null || url != undefined) {
      let route = '/' + url
      this.router.navigate([route]);
    }
  }


  /* SIDE BAR START */
  showHomeBar() {
    if (this.showHome == false) {
      this.showHome = true;
    }
    else {
      this.showHome = false;
    }
  }

  outOfAccordion() {

    $('#navbarSupportedContent1').hide();


    $('#navbarSupportedContent1').click(function (event) {
      event.stopPropagation();
    });
  }

  showAccordion() {
    $('#navbarSupportedContent1').show();
  }

  outOfHomeDiv() {
    $('#homeBarDiv').hide();
    $('#homeBarDiv').click(function (event) {
      event.stopPropagation();
    });
  }

  showHomeDiv() {
    $('#homeBarDiv').show();
    const $sideBox = $('#active-1');
    $sideBox.addClass('activeClass');
  }

  outOfStationDiv() {
    $('#stationBarDiv').hide();
    $('#stationBarDiv').click(function (event) {
      event.stopPropagation();
    });
  }

  showStationDiv() {
    $('#stationBarDiv').show();
    const $sideBox = $('#active-2');
    $sideBox.addClass('activeClass');
  }

  outOfReportsDiv() {
    $('#reportsBarDiv').hide();
    $('#reportsBarDiv').click(function (event) {
      event.stopPropagation();
    });
  }

  showReportsDiv() {
    $('#reportsBarDiv').show();
    const $sideBox = $('#active-3');
    $sideBox.addClass('activeClass');
  }

  /* SIDE BAR END */

}
