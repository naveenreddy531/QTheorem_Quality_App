import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  accordionHeader: any[] = [];
  dropDown2 = [];
  division: any;
  canal: any;
  historyData: any[] = [];
  startDate:any;
  endDate:any;
  Today: any;
  ngOnInit() {

    this.Today = new Date();
    var dd = this.Today.getDate();
    var mm = this.Today.getMonth() + 1;
    var yyyy = this.Today.getFullYear();
    if(dd < 10){
      dd = '0' + mm;
      if(mm < 10){
        mm = '0' + mm;
      }
      this.Today = yyyy + '-' + mm + '-'+ dd;
      if(navigator.userAgent.match(/Trident/)){
        this.Today = yyyy + '-' + mm + '/' + dd;
      }
    }
    this.startDate = this.Today;
    this.endDate = "YYYY-MM-dd"
  }
  constructor() {


    this.accordionHeader = [
      {
        id: 1,
        title: "KNNL_1",
        classId: "knnl1",
        canaldata: [
          {
            id: "KNNL_92",
            location: { lat: 14.4644, lng: 75.9218, data: "BRRB C 1.4 KM" },
            canalName: "Canal 1",
            date: "01-04-19 13:00",
            flow: "96.014",
            plannedFlow: "75.000",
            diff: "21.014",
            height: "4.698",
            active: true,
            historyData:[{

            date: "01-00-00 00:00",
            flow: "96.014",
            plannedFlow: "75.000",
            diff: "21.014",
            height: "4.698",
            },
            {
              date: "01-00-00 01:01",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              }
            ]

          },
          {
            id: "KNNL_93",
            location: { lat: 14.4644, lng: 75.9218, data: "BRRB C 1.4 KM" },
            canalName: "Canal 2",
            date: "01-04-19 14:00",
            flow: "96.014",
            plannedFlow: "75.000",
            diff: "21.014",
            height: "4.698",
            active: true,
            historyData:[{
              date: "01-04-19 1622:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              },
              {
                date: "01-04-19 1522:00",
                flow: "96.014",
                plannedFlow: "75.000",
                diff: "21.014",
                height: "4.698",
                }
              ]

          },


          {
            id: "KNNL_94",
            location: { lat: 14.4644, lng: 75.9218, data: "BRRB C 1.4 KM" },
            canalName: "Canal 3",
            date: "02-04-19 12:00",
            flow: "96.014",
            plannedFlow: "75.000",
            diff: "21.014",
            height: "4.698",
            active: true,
            historyData:[{
              date: "01-04-19 16333:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              },
              {
                date: "01-04-19 15333:00",
                flow: "96.014",
                plannedFlow: "75.000",
                diff: "21.014",
                height: "4.698",
                }
              ]

          }]
      },
      {
        id: 2,
        title: "KNNL_2",
        classId: "knnl2",
        canaldata: [
          {
            id: "KNNL_94",
            location: { lat: 14.4644, lng: 75.9218, data: "BRRB C 1.4 KM" },
            canalName: "Canal 3",
            date: "03-04-19 13:00",
            flow: "96.014",
            plannedFlow: "75.000",
            diff: "21.014",
            height: "4.698",
            active: true,
            historyData:[{
              date: "01-04-19 1633322222:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              },
              {
                date: "01-04-19 1533322222:00",
                flow: "96.014",
                plannedFlow: "75.000",
                diff: "21.014",
                height: "4.698",
                }
              ]

          }]

         
        
      }
    ];

  }

  onSelectDevice(data) {
    this.dropDown2 = [];
    this.accordionHeader.forEach(item => {
      if (item.title.trim() == data.trim()) {
        item.canaldata.forEach(element => {
          this.dropDown2.push(element.canalName)
        });
      }
    });
  }

  fetchHistory(division,canal,startDate){
    this.historyData =[];
    this.accordionHeader.forEach(item => {
      if (item.title.trim() == division ) {
        item.canaldata.forEach(element => {
           this.historyData.push({"id":element.id, "date":element.date,"height":element.height,
                            "flow":element.flow,"historyData":element.historyData          });
        console.log(this.historyData)
          });
      }
    });
//alert(division+canal);
  }
  
  onStartDateChange(data){
    console.log(this.startDate);
    console.log(this.Today - 30);
    if((Date.parse(this.Today) <= Date.parse(this.startDate)) || (Date.parse(this.Today) == Date.parse(this.startDate)))
    {

    } 
   
    else if(this.startDate.getDate <= this.Today.getDate -30){
      console.log(this.startDate);
      console.log(this.Today-30);
      alert("Start Date should not be less than 30 days from current date");
      this.startDate = this.Today;
    }
  // else{
  //   alert("Start Date should not be greater than current date");
  // }
  }
}
