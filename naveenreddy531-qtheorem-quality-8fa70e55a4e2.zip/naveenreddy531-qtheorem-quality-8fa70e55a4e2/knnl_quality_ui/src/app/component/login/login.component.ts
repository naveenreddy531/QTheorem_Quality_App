import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  showForgotPwd: boolean;
  constructor(private router: Router) { }

  ngOnInit() {
    this.showForgotPwd = false;
  }

  validateUser(){
    this.router.navigate(['/maps']);
  }

  login(){
    this.router.navigate(['/graph']);

  }

  showForgotPwdDiv(){
    if(this.showForgotPwd == true){
    this.showForgotPwd = false;
    }
    else{
      this.showForgotPwd = true;
    }
    

  }

}
