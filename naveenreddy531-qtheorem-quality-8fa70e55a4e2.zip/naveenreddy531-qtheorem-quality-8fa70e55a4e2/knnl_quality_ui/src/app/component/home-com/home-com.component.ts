import { Component, OnInit } from '@angular/core';
import { ApiservicesService } from '../../shared/apiservices.service';
import { Router } from '@angular/router';
import { MapsComponent } from '../maps/maps.component';
@Component({
  selector: 'app-home-com',
  templateUrl: './home-com.component.html',
  styleUrls: ['./home-com.component.css']
})
export class HomeComComponent implements OnInit {
  document: any;
  canaldata: any[] = [];
  accordionHeader: any[] = [];
  constructor(private shared: ApiservicesService, private router: Router) {
    // this.canaldata = ;

    this.accordionHeader = [
      {
        id: 1,
        title: "KNNL_1",
        classId: "knnl1",
        canaldata: [
          {
            id: 93,
            location: { lat: 14.4644, lng: 75.9218, data: "BRRB C 1.4 KM" },
            date: "01-04-19 13:00",
            flow: "96.014",
            plannedFlow: "75.000",
            diff: "21.014",
            height: "4.698",
            active: true

          }]
      },
      {
        id: 2,
        title: "KNNL_2",
        classId: "knnl2",
        canaldata: [
          {
            id: 94,
            location: { lat: 12.9007, lng: 80.1969, data: "BRRB C 1.4 KM" },
            date: "01-04-19 13:00",
            flow: "96.014",
            plannedFlow: "75.100",
            diff: "21.014",
            height: "4.698",
            active: true

          }]
      }
    ];

  }

  ngOnInit() {
    // $(document).foundation();    
    console.log(this.accordionHeader[0]['canaldata']);
  }

  openMap(data) {
    this.shared.setcurrentMapData(data);
    this.router.navigate(['/maps']);
  }




}
