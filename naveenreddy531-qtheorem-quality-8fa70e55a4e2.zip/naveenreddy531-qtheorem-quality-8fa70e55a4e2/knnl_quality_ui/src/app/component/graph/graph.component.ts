import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.css']
})
export class GraphComponent implements OnInit {
  dataSource: Object;
  chartConfig: Object;
  accordionHeader: any[] = [];
  division: any;
  canal: any;
  dropDown2 = [];
  constructor() {

    this.chartConfig = {
      width: '700',
      height: '400',
      type: 'column2d',
      dataFormat: 'json'
      
  };

  this.accordionHeader = [
    {
      id: "1",
      title: "KNNL_1",
      classId: "knnl1",
      canaldata: [
        {
          id: "KNNL_92",
          location: {
            lat: 14.4644,
            lng: 75.9218,
            data: "BRRB C 1.4 KM"
          },
          canalName: "Canal 1",
          date: "01-04-19 13:00",
          flow: "96.014",
          plannedFlow: "75.000",
          diff: "21.014",
          height: "4.698",
          active: true,
          historyData: [
            {
              date: "01-00-00 00:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              
            },
            {
              date: "01-00-00 01:01",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              
            }
          ]
        },
        {
          id: "KNNL_93",
          location: {
            lat: 14.4644,
            lng: 75.9218,
            data: "BRRB C 1.4 KM"
          },
          canalName: "Canal 2",
          date: "01-04-19 14:00",
          flow: "96.014",
          plannedFlow: "75.000",
          diff: "21.014",
          height: "4.698",
          active: true,
          historyData: [
            {
              date: "01-04-19 1622:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              
            },
            {
              date: "01-04-19 1522:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              
            }
          ]
        },
        {
          id: "KNNL_94",
          location: {
            lat: 14.4644,
            lng: 75.9218,
            data: "BRRB C 1.4 KM"
          },
          canalName: "Canal 3",
          date: "02-04-19 12:00",
          flow: "96.014",
          plannedFlow: "75.000",
          diff: "21.014",
          height: "4.698",
          active: true,
          historyData: [
            {
              date: "01-04-19 16333:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              
            },
            {
              date: "01-04-19 15333:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              
            }
          ]
        }
      ]
    },
    {
      id: "2",
      title: "KNNL_2",
      classId: "knnl2",
      canaldata: [
        {
          id: "KNNL_94",
          location: {
            lat: 14.4644,
            lng: 75.9218,
            data: "BRRB C 1.4 KM"
          },
          canalName: "Canal 3",
          date: "03-04-19 13:00",
          flow: "96.014",
          plannedFlow: "75.000",
          diff: "21.014",
          height: "4.698",
          active: true,
          historyData: [
            {
              date: "01-04-19 1633322222:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              
            },
            {
              date: "01-04-19 1533322222:00",
              flow: "96.014",
              plannedFlow: "75.000",
              diff: "21.014",
              height: "4.698",
              
            }
          ]
        }
      ]
    }
  ];

  this.dataSource = {
      "chart": {
        "caption": "Countries With Most Oil Reserves [2017-18]",
        "subCaption": "In MMbbl = One Million barrels",
        "xAxisName": "Country",
        "yAxisName": "Reserves (MMbbl)",
        "numberSuffix": "K",
        "theme": "gammel",
        "exportEnabled":"1"
      },
      "data": [{
        "label": "Venezuela",
        "value": "290"
      }, {
        "label": "Saudi",
        "value": "260"
      }, {
        "label": "Canada",
        "value": "180"
      }, {
        "label": "Iran",
        "value": "140"
      }, {
        "label": "Russia",
        "value": "115"
      }, {
        "label": "UAE",
        "value": "100"
      }, {
        "label": "US",
        "value": "30"
      }, {
        "label": "China",
        "value": "30"
      }]
    };


    

   }

   fetchHistory(division,canal){
    this.accordionHeader.forEach(item => {
      if (item.title.trim() == division ) {
        item.canaldata.forEach(element => {
           this.dataSource['data'].push({"id":element.id, "date":element.date,"height":element.height,
                            "flow":element.flow,"historyData":element.historyData          });
        console.log(JSON.stringify(this.dataSource));
          });
      }
    });
   }

   onSelectDevice(data) {
    this.dropDown2 = [];
    this.accordionHeader.forEach(item => {
      if (item.title.trim() == data.trim()) {
        item.canaldata.forEach(element => {
          this.dropDown2.push(element.canalName)
        });
      }
    });
  }

   callService(){
     
   }

  ngOnInit() {
  }

}
