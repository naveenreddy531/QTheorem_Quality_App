import { Component, OnInit } from '@angular/core';
import * as $ from "jquery";


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    const $menu = $('#burger');
    const $sidebar = $('.sidebar');
    const $sidebarItemTitles = $('.sidebar-item-title');

    let isOpen = true;

    $menu.on('click', () => {
      if (isOpen) {
        $sidebarItemTitles.addClass('hide');
        $sidebar.removeClass('expanded');
      } else {
        $sidebarItemTitles.removeClass('hide');
        $sidebar.addClass('expanded');
      }
      isOpen = !isOpen
    })
  }

}
