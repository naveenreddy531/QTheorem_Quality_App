import { Injectable } from '@angular/core';

@Injectable()
export class ApiservicesService {

  currentLat: any[] = [];
  currentLong: any[] = [];
  currentData:any[] = [];
  accordionHeader: any[] = [];
  selectedStation: any;

  constructor() { 

    this.accordionHeader =     [
      {
        id: 1,
        division: "KNNL_1",
        classId: "knnl1",
        stations: [
          {
            id: "KNNL_92",
            location: { lat: 14.4644, lng: 75.9218, data: "BRRB C 1.4 KM" },
            stationName: "Canal 1",
			stationType:"Immersion",
			stationCategory:"Ground Level Resorvior",
			deviceId:"777",
			simNo:"8787887878",
			phoneNr:"99988776655",
            date: "01-04-19 13:00",
            active: true,
            historyData:[{
  
            date: "01-00-00 00:00",
            flow: "96.014",
           
            },
            {
              date: "01-00-00 01:01",
              flow: "96.014",
              
              }
            ]
  
          },
          {
            id: "KNNL_93",
            location: { lat: 14.4644, lng: 75.9218, data: "BRRB C 1.4 KM" },
            stationName: "Canal 2",
        stationType:"Immersion",
        stationCategory:"Ground Level Resorvior",
        deviceId:"777",
        simNo:"8787887878",
        phoneNr:"99988776655",
            
            active: true,
            historyData:[{
              date: "01-04-19 1622:00",
              flow: "96.014",
             
              },
              {
                date: "01-04-19 1522:00",
                flow: "96.014",
               
                }
              ]
  
          },
  
  
          {
            id: "KNNL_94",
            location: { lat: 14.4644, lng: 75.9218, data: "BRRB C 1.4 KM" },
            stationName: "Canal 3",
        stationType:"Immersion",
        stationCategory:"Ground Level Resorvior",
        deviceId:"777",
        simNo:"8787887878",
        phoneNr:"99988776655",
           
            active: true,
            historyData:[{
              date: "01-04-19 16333:00",
              flow: "96.014",
             
              },
              {
                date: "01-04-19 15333:00",
                flow: "96.014",
                
                }
              ]
  
          }]
      }
      ];
    
  
  
  
  
  }

  setcurrentMapData(data){
    this.currentLat = data.lat;
    this.currentLong = data.lng;
    this.currentData = data.data;

  } 

  setSelectedStation(stationName){
    this.selectedStation = stationName;
  }

  

  

}
