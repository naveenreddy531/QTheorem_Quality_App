import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApiservicesService } from '../app/shared/apiservices.service';
import * as $ from "jquery";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  constructor(private shared: ApiservicesService, private router: Router) {


    

  }

  

  showSideBar: boolean = false;

  openNav() {
    if (this.showSideBar) {
      this.showSideBar = false;
    }
    else {
      this.showSideBar = true;
    }
  }

  closeNav() {
    this.showSideBar = false;
  }


  ngOnInit() {
    var queryString = window.location.search.slice(1);
    var arr = queryString.split('=');
    if(arr[1] != null || arr[1]!= undefined){
      this.router.navigate(['/'+arr[1]]);
    }
    const $menu = $('#burger');
    const $sidebar = $('.sidebar');
    const $sidebarItemTitles = $('.sidebar-item-title');

    let isOpen = true;

    $menu.on('click', () => {
      if (isOpen) {
        $sidebarItemTitles.addClass('hide');
        $sidebar.removeClass('expanded');
      } else {
        $sidebarItemTitles.removeClass('hide');
        $sidebar.addClass('expanded');
      }
      isOpen = !isOpen
    })


  }
  

  // openLink(compName) {
  //   if (compName == "Home") {
  //     this.router.navigate(['/home']);
  //     this.closeNav();
  //   }
  //   else if (compName == "Maps") {
  //     this.router.navigate(['/maps']);
  //     this.closeNav();
  //   }
  //   else if (compName == "History") {
  //     this.router.navigate(['/history']);
  //     this.closeNav();
  //   }
  //   else if (compName == "Graph") {
  //     this.router.navigate(['/graph']);
  //     this.closeNav();
  //   } else if (compName == "Station") {
  //     this.router.navigate(['/station']);
  //     this.closeNav();
  //   } else if (compName == "Report") {
  //     this.router.navigate(['/reports']);
  //     this.closeNav();
  //   }
  // }
}
