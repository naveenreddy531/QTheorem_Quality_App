package com.qtmquality.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KnnlQualityApplication {

	public static void main(String[] args) {
		SpringApplication.run(KnnlQualityApplication.class, args);
	}
}
